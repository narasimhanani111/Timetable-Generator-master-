import java.util.*; 
public class Timetable{
    private String name;
    String a[][] = new String[6][8];  
    void setName(String s){
        this.name=s;
    } 
    String getName(){
        return this.name;
    }
}